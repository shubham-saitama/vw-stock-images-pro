<?php
/*
 Plugin Name: VW Social Media
 Plugin URI: https://www.vwthemes.com/
 Description: Use to create and display Social Media
 Author: VW Themes
 Version: 1.0
 Author URI: https://www.vwthemes.com/
*/

if (!defined('ABSPATH')) {
    exit; //Exit if accessed directly
}

define( 'VWSMP_VERSION', '1.0' );

define( 'VWSMP_REQUIRED_WP_VERSION', '4.9' );

if ( ! defined( 'VWSMP_DIR_URL' ) )
    define( 'VWSMP_DIR_URL', plugin_dir_url( __FILE__ ) );

// Loading Translation
if ( ! function_exists ( 'vwsmp_plugins_loaded' ) ) {

	function vwsmp_plugins_loaded() {
		/* Internationalization */
		load_plugin_textdomain( 'vw-social-media', false, VWSMP_DIR_URL . '/languages/' );
	}
}

/*Enqueue Admin Setting Files */
require_once( plugin_dir_path( __FILE__ ).'admin/vwsmp-admin-settings.php');

/* Enqueue Shortcodes Files */
require_once( plugin_dir_path( __FILE__ ).'vwsmp-shortcodes.php');

/* Enqueue Front Data Files */
require_once( plugin_dir_path( __FILE__ ).'admin/front-data.php');

/* Plugin Style And Script */
add_action( 'wp_enqueue_scripts', 'vwsmp_style_scripts' );

function vwsmp_style_scripts() {

    // Style for front page section
    wp_enqueue_style( 'vwsmp-style', VWSMP_DIR_URL . 'assets/css/vwsmp-style.css');

    //Fontawesome Style
    wp_enqueue_style( 'fontawesome', VWSMP_DIR_URL . 'assets/css/fontawesome-all.min.css');
}

// Color Picker
add_action( 'admin_enqueue_scripts', 'vwsmp_color_picker' );

function vwsmp_color_picker( $hook ) {
    
 	// Style for dashboard section
 	wp_enqueue_style( 'vwsmp-admin-style', VWSMP_DIR_URL . 'assets/css/vwsmp-admin-style.css');

    // Add the color picker css and js file       
    wp_enqueue_style( 'wp-color-picker' ); 
    wp_enqueue_script( 'wp-color-picker' ); 
     
    // Include our custom jQuery file with WordPress Color Picker dependency
    wp_enqueue_script( 'dynamic-fields-js', VWSMP_DIR_URL . 'assets/js/dynamic-fields.js', array( 'jquery' ) ); 
}