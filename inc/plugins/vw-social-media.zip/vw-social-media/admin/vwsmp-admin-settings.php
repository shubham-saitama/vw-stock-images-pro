<?php

// Plugin Page
$vwsmp_options = "";
$vwsmp_options = get_option('vwsmp_options');

function vwsmp_get_social_data(){

  // Globle Variable
  global $vwsmp_options;

  // facebook
  $vwsmp_facebook = isset($vwsmp_options['vwsmp_facebook']) ? $vwsmp_options['vwsmp_facebook'] :  '';

  // Twitter
  $vwsmp_twitter = isset($vwsmp_options['vwsmp_twitter']) ? $vwsmp_options['vwsmp_twitter'] :  '';

  // Google+
  $vwsmp_google = isset($vwsmp_options['vwsmp_google']) ? $vwsmp_options['vwsmp_google'] :  '';

  // Instagram
  $vwsmp_instagram = isset($vwsmp_options['vwsmp_instagram']) ? $vwsmp_options['vwsmp_instagram'] :  '';

  // Flickr
  $vwsmp_flickr = isset($vwsmp_options['vwsmp_flickr']) ? $vwsmp_options['vwsmp_flickr'] :  '';

  // Pinterest
  $vwsmp_pinterest = isset($vwsmp_options['vwsmp_pinterest']) ? $vwsmp_options['vwsmp_pinterest'] :  '';

  // YouTube
  $vwsmp_youtube = isset($vwsmp_options['vwsmp_youtube']) ? $vwsmp_options['vwsmp_youtube'] :  '';

  // Skype
  $vwsmp_skype = isset($vwsmp_options['vwsmp_skype']) ? $vwsmp_options['vwsmp_skype'] :  '';

  // Tumblr
  $vwsmp_tumblr = isset($vwsmp_options['vwsmp_tumblr']) ? $vwsmp_options['vwsmp_tumblr'] :  '';

  // Wordpress
  $vwsmp_wordpress = isset($vwsmp_options['vwsmp_wordpress']) ? $vwsmp_options['vwsmp_wordpress'] :  '';

  // RSS
  $vwsmp_rss = isset($vwsmp_options['vwsmp_rss']) ? $vwsmp_options['vwsmp_rss'] :  '';

  // VK
  $vwsmp_vk = isset($vwsmp_options['vwsmp_vk']) ? $vwsmp_options['vwsmp_vk'] :  '';

  // Custom icon 1
  $vwsmp_custom_1 = isset($vwsmp_options['vwsmp_custom_1']) ? $vwsmp_options['vwsmp_custom_1'] :  '';

  // Custom Font icon 1
  $vwsmp_custom_1_icon = isset($vwsmp_options['vwsmp_custom_1_icon']) ? $vwsmp_options['vwsmp_custom_1_icon'] :  '';

  // Custom icon 2
  $vwsmp_custom_2 = isset($vwsmp_options['vwsmp_custom_2']) ? $vwsmp_options['vwsmp_custom_2'] :  '';

  // Custom Font icon 2
  $vwsmp_custom_2_icon = isset($vwsmp_options['vwsmp_custom_2_icon']) ? $vwsmp_options['vwsmp_custom_2_icon'] :  '';

  // Custom icon 3
  $vwsmp_custom_3 = isset($vwsmp_options['vwsmp_custom_3']) ? $vwsmp_options['vwsmp_custom_3'] :  '';

  // Custom Font icon 3
  $vwsmp_custom_3_icon = isset($vwsmp_options['vwsmp_custom_3_icon']) ? $vwsmp_options['vwsmp_custom_3_icon'] :  '';

  // Custom icon 4
  $vwsmp_custom_4 = isset($vwsmp_options['vwsmp_custom_4']) ? $vwsmp_options['vwsmp_custom_4'] :  '';

  // Custom Font icon 4
  $vwsmp_custom_4_icon = isset($vwsmp_options['vwsmp_custom_4_icon']) ? $vwsmp_options['vwsmp_custom_4_icon'] :  '';

  // Custom icon 5
  $vwsmp_custom_5 = isset($vwsmp_options['vwsmp_custom_5']) ? $vwsmp_options['vwsmp_custom_5'] :  '';

  // Custom Font icon 5
  $vwsmp_custom_5_icon = isset($vwsmp_options['vwsmp_custom_5_icon']) ? $vwsmp_options['vwsmp_custom_5_icon'] :  '';

  // Style
  $vwsmp_admin_radio_style = isset($vwsmp_options['vwsmp_admin_radio_style']) ? $vwsmp_options['vwsmp_admin_radio_style'] :  '';
}
add_action( 'admin_init', 'vwsmp_get_social_data' );

/**
* For Register Custom Menu page in dashboard
*/
add_action( 'admin_menu', 'register_custom_menu_page' );

  function register_custom_menu_page() {

    add_menu_page('VW Social Media', 'VW Social Media', 'add_users', 'vw-social-media', 'vwsmp_about_render', null, 6);

    add_action( 'admin_init', 'vwsmp_register_settings' );
}

//call register settings function
function vwsmp_register_settings() {

  register_setting('vwsmp-plugin-option', 'vwsmp_options', 'vwsmp_validate_options');
}

function vwsmp_about_render(){

  global $title;   global $vwsmp_options;?>

    <div id="vwsmp_dashboard">

        <div class="vwsmp_title">
            <h1>
                <img src="<?php echo esc_attr( VWSMP_DIR_URL . 'assets/images/logo.png'); ?>"><?php echo esc_html($title); ?>
                <span class="vwsmp-version"><?php echo esc_html('Version 1.0', 'vw-social-media'); ?></span>
            </h1>
        </div>

        <div class="col-md-8 vwsmp-dash">

            <form method="post" action="options.php">
                <?php settings_fields( 'vwsmp-plugin-option' ); ?>

                    <div class="vwsmp-enable">
                        <h2><?php echo esc_html('Enable', 'vw-social-media'); ?></h2>
                        <div class="enable_data">
                            <label for="vwsmp_admin_check_enable"><?php echo esc_html('Show / hide'); ?></label>
                            <input type="checkbox" id="vwsmp_admin_check_enable" name="vwsmp_options[vwsmp_admin_check_enable]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_enable'])) { checked(1, $vwsmp_options['vwsmp_admin_check_enable']); } ?> />
                        </div>
                    </div>

                    <div class="vwsmp_position">
                        <h2 scope="row"><?php echo esc_html('Position', 'vw-social-media'); ?></h2>

                        <div class="position_data">

                            <span class="position_option">
                                <input type="radio" id="left-center" name="vwsmp_options[vwsmp_admin_radio]" value="left-center" <?php checked( 'left-center' == $vwsmp_options['vwsmp_admin_radio'] ); ?>  />
                                <label for="left-center"><?php echo esc_html('Left Center','vw-social-media'); ?></label>
                            </span>

                            <span class="position_option">
                                <input type="radio" id="top-center" name="vwsmp_options[vwsmp_admin_radio]" value="top-center" <?php checked( 'top-center' == $vwsmp_options['vwsmp_admin_radio'] ); ?> />
                                <label for="top-center"><?php echo esc_html('Top Center','vw-social-media'); ?></label>
                            </span>

                            <span class="position_option">
                                <input type="radio" id="bottom-center" name="vwsmp_options[vwsmp_admin_radio]" value="bottom-center" <?php checked( 'bottom-center' == $vwsmp_options['vwsmp_admin_radio'] ); ?> />
                                <label for="bottom-center"><?php echo esc_html('Bottom Center','vw-social-media'); ?></label>
                            </span>

                            <span class="position_option">
                                <input type="radio" id="right-center" name="vwsmp_options[vwsmp_admin_radio]" value="right-center" <?php checked( 'right-center' == $vwsmp_options['vwsmp_admin_radio'] ); ?> />
                                <label for="right-center"><?php echo esc_html('Right Center','vw-social-media'); ?></label>
                            </span>

                        </div>
                    </div>

                    <div class="configuration_box">

                       <h2><?php echo esc_html('Social Icon Configuration', 'vw-social-media'); ?></h2>


                        <div class="in_clear">

                            <div class="col-md-4"><h4><?php echo esc_html('Facebook', 'vw-social-media'); ?></h4>
                            </div>

                            <div class="input_box" >

                              <input type="url" name="vwsmp_options[vwsmp_facebook]" value="<?php echo $vwsmp_options['vwsmp_facebook']; ?>" />

                              <label for="vwsmp_admin_check_facebook"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_facebook" name="vwsmp_options[vwsmp_admin_check_facebook]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_facebook'])) { checked(1, $vwsmp_options['vwsmp_admin_check_facebook']); } ?> />

                            </div>

                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Twitter', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_twitter]" value="<?php echo $vwsmp_options['vwsmp_twitter']; ?>" />

                              <label for="vwsmp_admin_check_twitter"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_twitter" name="vwsmp_options[vwsmp_admin_check_twitter]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_twitter'])) { checked(1, $vwsmp_options['vwsmp_admin_check_twitter']); } ?> />

                             </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Google+', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_google]" value="<?php echo $vwsmp_options['vwsmp_google']; ?>" />

                              <label for="vwsmp_admin_check_google"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_google" name="vwsmp_options[vwsmp_admin_check_google]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_google'])) { checked(1, $vwsmp_options['vwsmp_admin_check_google']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Instagram', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_instagram]" value="<?php echo $vwsmp_options['vwsmp_instagram']; ?>" />

                              <label for="vwsmp_admin_check_instagram"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_instagram" name="vwsmp_options[vwsmp_admin_check_instagram]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_instagram'])) { checked(1, $vwsmp_options['vwsmp_admin_check_instagram']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Flickr', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_flickr]" value="<?php echo $vwsmp_options['vwsmp_flickr']; ?>" />

                              <label for="vwsmp_admin_check_flickr"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_flickr" name="vwsmp_options[vwsmp_admin_check_flickr]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_flickr'])) { checked(1, $vwsmp_options['vwsmp_admin_check_flickr']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Pinterest', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_pinterest]" value="<?php echo $vwsmp_options['vwsmp_pinterest']; ?>" />

                              <label for="vwsmp_admin_check_pinterest"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_pinterest" name="vwsmp_options[vwsmp_admin_check_pinterest]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_pinterest'])) { checked(1, $vwsmp_options['vwsmp_admin_check_pinterest']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('YouTube', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_youtube]" value="<?php echo $vwsmp_options['vwsmp_youtube']; ?>" />

                              <label for="vwsmp_admin_check_youtube"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_youtube" name="vwsmp_options[vwsmp_admin_check_youtube]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_youtube'])) { checked(1, $vwsmp_options['vwsmp_admin_check_youtube']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Skype', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_skype]" value="<?php echo $vwsmp_options['vwsmp_skype']; ?>" />

                              <label for="vwsmp_admin_check_skype"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_skype" name="vwsmp_options[vwsmp_admin_check_skype]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_skype'])) { checked(1, $vwsmp_options['vwsmp_admin_check_skype']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Tumblr', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_tumblr]" value="<?php echo $vwsmp_options['vwsmp_tumblr']; ?>" />

                              <label for="vwsmp_admin_check_tumblr"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_tumblr" name="vwsmp_options[vwsmp_admin_check_tumblr]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_tumblr'])) { checked(1, $vwsmp_options['vwsmp_admin_check_tumblr']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('WordPress', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_wordpress]" value="<?php echo $vwsmp_options['vwsmp_wordpress']; ?>" />

                              <label for="vwsmp_admin_check_wordpress"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_wordpress" name="vwsmp_options[vwsmp_admin_check_wordpress]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_wordpress'])) { checked(1, $vwsmp_options['vwsmp_admin_check_wordpress']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('RSS', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_rss]" value="<?php echo $vwsmp_options['vwsmp_rss']; ?>" />

                              <label for="vwsmp_admin_check_rss"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_rss" name="vwsmp_options[vwsmp_admin_check_rss]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_rss'])) { checked(1, $vwsmp_options['vwsmp_admin_check_rss']); } ?> />

                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('VK', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_vk]" value="<?php echo $vwsmp_options['vwsmp_vk']; ?>" />

                              <label for="vwsmp_admin_check_vk"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_vk" name="vwsmp_options[vwsmp_admin_check_vk]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_vk'])) { checked(1, $vwsmp_options['vwsmp_admin_check_vk']); } ?> />
                          </div>
                        </div>
                    </div>
                    <div class="custom_create_box">

                       <h2><?php echo esc_html(' Create Custom Icon', 'vw-social-media'); ?></h2>

                       <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Custom Icon 1', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_custom_1]" value="<?php echo $vwsmp_options['vwsmp_custom_1']; ?>" />

                             <label for="vwsmp_admin_check_custom_1"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_custom_1" name="vwsmp_options[vwsmp_admin_check_custom_1]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_custom_1'])) { checked(1, $vwsmp_options['vwsmp_admin_check_custom_1']); } ?> />
                            </div>
                            <div>
                              <h4 class="col-md-4"><label><?php echo esc_html('Font Awesome class 1','vw-social-media'); ?></label></h4>

                                <input type="text" name="vwsmp_options[vwsmp_custom_1_icon]" value="<?php echo $vwsmp_options['vwsmp_custom_1_icon']; ?>" />
                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Custom Icon 2', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_custom_2]" value="<?php echo $vwsmp_options['vwsmp_custom_2']; ?>" />

                              <label for="vwsmp_admin_check_custom_2"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_custom_2" name="vwsmp_options[vwsmp_admin_check_custom_2]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_custom_2'])) { checked(1, $vwsmp_options['vwsmp_admin_check_custom_2']); } ?> />
                            </div>
                             <div>
                              <h4 class="col-md-4"><label><?php echo esc_html('Font Awesome class 2','vw-social-media'); ?></label></h4>

                                <input type="text" name="vwsmp_options[vwsmp_custom_2_icon]" value="<?php echo $vwsmp_options['vwsmp_custom_2_icon']; ?>" />
                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Custom Icon 3', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_custom_3]" value="<?php echo $vwsmp_options['vwsmp_custom_3']; ?>" />

                              <label for="vwsmp_admin_check_custom_3"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_custom_3" name="vwsmp_options[vwsmp_admin_check_custom_3]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_custom_3'])) { checked(1, $vwsmp_options['vwsmp_admin_check_custom_3']); } ?> />
                            </div>
                             <div>
                              <h4 class="col-md-4"><label><?php echo esc_html('Font Awesome class 3','vw-social-media'); ?></label></h4>

                                <input type="text" name="vwsmp_options[vwsmp_custom_3_icon]" value="<?php echo $vwsmp_options['vwsmp_custom_3_icon']; ?>" />
                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Custom Icon 4', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_custom_4]" value="<?php echo $vwsmp_options['vwsmp_custom_4']; ?>" />

                              <label for="vwsmp_admin_check_custom_4"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_custom_4" name="vwsmp_options[vwsmp_admin_check_custom_4]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_custom_4'])) { checked(1, $vwsmp_options['vwsmp_admin_check_custom_4']); } ?> />
                            </div>
                             <div>
                              <h4 class="col-md-4"><label><?php echo esc_html('Font Awesome class 4','vw-social-media'); ?></label></h4>

                                <input type="text" name="vwsmp_options[vwsmp_custom_4_icon]" value="<?php echo $vwsmp_options['vwsmp_custom_4_icon']; ?>" />
                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4"><h4><?php echo esc_html('Custom Icon 5', 'vw-social-media'); ?></h4>
                            </div>
                            <div>

                              <input type="url" name="vwsmp_options[vwsmp_custom_5]" value="<?php echo $vwsmp_options['vwsmp_custom_5']; ?>" />

                              <label for="vwsmp_admin_check_custom_5"><?php echo esc_html('Show / hide','vw-social-media'); ?></label>

                              <input type="checkbox" id="vwsmp_admin_check_custom_5" name="vwsmp_options[vwsmp_admin_check_custom_5]" value="1" <?php if (isset($vwsmp_options['vwsmp_admin_check_custom_5'])) { checked(1, $vwsmp_options['vwsmp_admin_check_custom_5']); } ?> />
                            </div>
                             <div>
                              <h4 class="col-md-4"><label><?php echo esc_html('Font Awesome class 5','vw-social-media'); ?></label></h4>

                                <input type="text" name="vwsmp_options[vwsmp_custom_5_icon]" value="<?php echo $vwsmp_options['vwsmp_custom_5_icon']; ?>" />
                            </div>
                        </div>
                    </div>

                    <div class="appearance_box">

                        <h2><?php echo esc_html('Social Icon Appearance','vw-social-media'); ?></h2>

                        <div class="in_clear">
                            <div class="col-md-4">
                                <h4><?php echo esc_html('Color','vw-social-media'); ?></h4>
                            </div>
                            <div>
                                <input class="color-field" type="text" name="vwsmp_options[vwsmp_color]" value="<?php echo esc_attr($vwsmp_options['vwsmp_color']); ?>" />
                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4">
                                <h4><?php echo esc_html('Hover Color', 'vw-social-media'); ?></h4>
                            </div>
                            <div>
                                <input class="color-field" type="text" name="vwsmp_options[vwsmp_hover_color]" value="<?php echo $vwsmp_options['vwsmp_hover_color']; ?>" />
                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4">
                                <h4><?php echo esc_html('Background Color', 'vw-social-media'); ?></h4>
                            </div>
                            <div>
                                <input class="color-field" type="text" name="vwsmp_options[vwsmp_background_color]" value="<?php echo $vwsmp_options['vwsmp_background_color']; ?>" />
                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4">
                                <h4><?php echo esc_html('Background Hover Color', 'vw-social-media'); ?></h4>
                            </div>
                            <div>
                                <input class="color-field" type="text" name="vwsmp_options[vwsmp_background_hover_color]" value="<?php echo $vwsmp_options['vwsmp_background_hover_color']; ?>" />
                            </div>
                        </div>

                        <div class="in_clear">
                            <div class="col-md-4">
                                <h4><?php echo esc_html('Font Size (px)', 'vw-social-media'); ?></h4>
                            </div>
                            <div>
                                <input name="vwsmp_options[vwsmp_font_size]" type="number" step="1" min="0" id="vwsmp_font_size" value="<?php echo $vwsmp_options['vwsmp_font_size']; ?>" class="small-text"  />
                            </div>
                        </div>

                        <div class="in_clear">
                           <div class="col-md-4">
                              <h4><?php echo esc_html('Border Radius (px)', 'vw-social-media'); ?></h4>
                           </div>
                           <div>
                              <input name="vwsmp_options[vwsmp_border_radius]" type="number" step="1" min="0" id="vwsmp_border_radius" value="<?php echo $vwsmp_options['vwsmp_border_radius']; ?>" class="small-text"  />
                           </div>
                        </div>

                    <div class="in_clear">
                        <div class="col-md-4"><h4><?php echo esc_html('Margin (px)', 'vw-social-media'); ?></h4>
                        </div>
                        <div>

                            <label><?php echo esc_html('Top'); ?></label>
                            <input name="vwsmp_options[vwsmp_margin_top]" type="number" step="1" min="0" id="vwsmp_margin_top" value="<?php echo $vwsmp_options['vwsmp_margin_top']; ?>" class="small-text"  />

                            <label><?php echo esc_html('Right'); ?></label>
                            <input name="vwsmp_options[vwsmp_margin_right]" type="number" step="1" min="0" id="vwsmp_margin_right" value="<?php echo $vwsmp_options['vwsmp_margin_right']; ?>" class="small-text"  />

                            <label><?php echo esc_html('Bottom'); ?></label>
                            <input name="vwsmp_options[vwsmp_margin_bottom]" type="number" step="1" min="0" id="vwsmp_margin_bottom" value="<?php echo $vwsmp_options['vwsmp_margin_bottom']; ?>" class="small-text"  />

                            <label><?php echo esc_html('Left'); ?></label>
                            <input name="vwsmp_options[vwsmp_margin_left]" type="number" step="1" min="0" id="vwsmp_margin_left" value="<?php echo $vwsmp_options['vwsmp_margin_left']; ?>" class="small-text"  />

                        </div>
                    </div>

                    <div class="in_clear">
                        <div class="col-md-4"><h4 class="style_sce"><?php echo esc_html('Style', 'vw-social-media'); ?></h4>
                        </div>
                        <div>
                            <span class="position_option">

                                <input type="radio" id="circle-style" name="vwsmp_options[vwsmp_admin_radio_style]" value="circle-style" <?php checked( 'circle-style' == $vwsmp_options['vwsmp_admin_radio_style'] ); ?>  />

                                <label for="circle-style"><img src="<?php echo esc_attr( VWSMP_DIR_URL . 'assets/images/circle.png'); ?>"></label>
                            </span>

                            <span class="position_option">

                                <input type="radio" id="rounded-style" name="vwsmp_options[vwsmp_admin_radio_style]" value="rounded-style" <?php checked( 'rounded-style' == $vwsmp_options['vwsmp_admin_radio_style'] ); ?> />

                                <label for="rounded-style"><img src="<?php echo esc_attr(  VWSMP_DIR_URL . 'assets/images/rounded.png'); ?>"></label>
                            </span>

                            <span class="position_option">

                                <input type="radio" id="square-style" name="vwsmp_options[vwsmp_admin_radio_style]" value="square-style" <?php checked( 'square-style' == $vwsmp_options['vwsmp_admin_radio_style'] ); ?> />

                                <label for="square-style"><img src="<?php echo esc_attr( VWSMP_DIR_URL . 'assets/images/square.png');?>"></label>
                            </span>
                        </div>
                    </div>
                    </div>
                      <div class="shortcodes_box">
                        <h2><?php echo esc_html('Shortcodes', 'vw-social-media'); ?></h2>
                        <div>
                              <p><?php echo esc_html('You can use shortcode in the content of required page where you want to display Social Media.', 'vw-social-media'); ?></p>

                              <p class="add_short"><code><?php echo esc_html('[vwsmp-social-media]', 'vw-social-media'); ?></code></p>

                              <p class="add_stt"><?php echo esc_html('For additional option you can below shortcode', 'vw-social-media'); ?> <br>
                              </p>

                              <p>
                                <code><?php echo esc_html('[vwsmp-social-media color="#ff0" hover_color="#f0f" bg_color="#000" bg_hover_color= "#0ff" font_size="18" border_radius="50" left_margin="5" right_margin="0" top_margin="10" bottom_margin="10" height="35" width="35"]', 'vw-social-media'); ?>
                                </code>
                              </p>
                        </div>
                      </div>
                <?php submit_button(); ?>
            </form>
        </div>

        <div class="col-md-4 rate_us_box">

            <h2><?php echo esc_html('Rate us on wordpress.org', 'vw-social-media'); ?></h2>

            <p class="thank_msg"><?php echo esc_html('If you enjoy the plugin please rate us', 'vw-social-media'); ?></p>

            <div class="star_dash">

              <img src="<?php echo esc_attr( VWSMP_DIR_URL . 'assets/images/star.png'); ?>">
              <img src="<?php echo esc_attr( VWSMP_DIR_URL . 'assets/images/star.png'); ?>">
              <img src="<?php echo esc_attr( VWSMP_DIR_URL . 'assets/images/star.png'); ?>">
              <img src="<?php echo esc_attr( VWSMP_DIR_URL . 'assets/images/star.png'); ?>">
              <img src="<?php echo esc_attr( VWSMP_DIR_URL . 'assets/images/star.png'); ?>">

            </div>

            <p class="thank_btn"><a href="https://www.vwthemes.com/" target="_blank"><?php echo esc_html('Click Here', 'vw-social-media'); ?></a></p>

            <p><?php echo esc_html('If you face obstacle, do write at plugins support forum ', 'vw-social-media'); ?><a href="https://www.vwthemes.com/support/" target="_blank"><?php echo esc_html('click here', 'vw-social-media'); ?></a>
            </p>
        </div>

    </div>

    <?php
}

function vwsmp_validate_options($input) {

  // Enable
  if (!isset($input['vwsmp_admin_check_enable'])) $input['vwsmp_admin_check_enable'] = null;
        $input['vwsmp_admin_check_enable'] = ($input['vwsmp_admin_check_enable'] == 1 ? 1 : 0);
  if (isset($_POST['submit'])) {

        if(isset($_POST['vwsmp_admin_radio']))
        {
             echo "You have selected :".$_POST['vwsmp_admin_radio'];  //  Displaying Selected Value
        }
        if(isset($_POST['vwsmp_admin_radio_style']))
        {
            echo "You have selected :".$_POST['vwsmp_admin_radio_style'];  //  Displaying Selected Value
        }
    }

    // Facebook
    if (!isset($input['vwsmp_facebook'])){
        $input['vwsmp_facebook']     = null;
    }
    else{
        $input['vwsmp_facebook']     = esc_attr($input['vwsmp_facebook']);
    }

    if (!isset($input['vwsmp_admin_check_facebook'])) $input['vwsmp_admin_check_facebook'] = null;
        $input['vwsmp_admin_check_facebook'] = ($input['vwsmp_admin_check_facebook'] == 1 ? 1 : 0);

    // Twitter
    if (!isset($input['vwsmp_twitter'])){
        $input['vwsmp_twitter']     = null;
    }
    else{
        $input['vwsmp_twitter']     = esc_attr($input['vwsmp_twitter']);
    }

    if (!isset($input['vwsmp_admin_check_twitter'])) $input['vwsmp_admin_check_twitter'] = null;
        $input['vwsmp_admin_check_twitter'] = ($input['vwsmp_admin_check_twitter'] == 1 ? 1 : 0);

    // Google+
    if (!isset($input['vwsmp_google'])){
        $input['vwsmp_google']     = null;
    }
    else{
        $input['vwsmp_google']     = esc_attr($input['vwsmp_google']);
    }

    if (!isset($input['vwsmp_admin_check_google'])) $input['vwsmp_admin_check_google'] = null;
        $input['vwsmp_admin_check_google'] = ($input['vwsmp_admin_check_google'] == 1 ? 1 : 0);

    // Instagram
    if (!isset($input['vwsmp_instagram'])){
        $input['vwsmp_instagram']     = null;
    }
    else{
        $input['vwsmp_instagram']     = esc_attr($input['vwsmp_instagram']);
    }

    if (!isset($input['vwsmp_admin_check_instagram'])) $input['vwsmp_admin_check_instagram'] = null;
        $input['vwsmp_admin_check_instagram'] = ($input['vwsmp_admin_check_instagram'] == 1 ? 1 : 0);

    // Flickr
    if (!isset($input['vwsmp_flickr'])){
        $input['vwsmp_flickr']     = null;
    }
    else{
        $input['vwsmp_flickr']     = esc_attr($input['vwsmp_flickr']);
    }

    if (!isset($input['vwsmp_admin_check_flickr'])) $input['vwsmp_admin_check_flickr'] = null;
        $input['vwsmp_admin_check_flickr'] = ($input['vwsmp_admin_check_flickr'] == 1 ? 1 : 0);

    // Pinterest
    if (!isset($input['vwsmp_pinterest'])){
        $input['vwsmp_pinterest']     = null;
    }
    else{
        $input['vwsmp_pinterest']     = esc_attr($input['vwsmp_pinterest']);
    }

    if (!isset($input['vwsmp_admin_check_pinterest'])) $input['vwsmp_admin_check_pinterest'] = null;
        $input['vwsmp_admin_check_pinterest'] = ($input['vwsmp_admin_check_pinterest'] == 1 ? 1 : 0);

    // Youtube
    if (!isset($input['vwsmp_youtube'])){
        $input['vwsmp_youtube']     = null;
    }
    else{
        $input['vwsmp_youtube']     = esc_attr($input['vwsmp_youtube']);
    }

    if (!isset($input['vwsmp_admin_check_youtube'])) $input['vwsmp_admin_check_youtube'] = null;
        $input['vwsmp_admin_check_youtube'] = ($input['vwsmp_admin_check_youtube'] == 1 ? 1 : 0);

    // skype
    if (!isset($input['vwsmp_skype'])){
        $input['vwsmp_skype']     = null;
    }
    else{
        $input['vwsmp_skype']     = esc_attr($input['vwsmp_skype']);
    }

    if (!isset($input['vwsmp_admin_check_skype'])) $input['vwsmp_admin_check_skype'] = null;
        $input['vwsmp_admin_check_skype'] = ($input['vwsmp_admin_check_skype'] == 1 ? 1 : 0);

    // Tumblr
    if (!isset($input['vwsmp_tumblr'])){
        $input['vwsmp_tumblr']     = null;
    }
    else{
        $input['vwsmp_tumblr']     = esc_attr($input['vwsmp_tumblr']);
    }

    if (!isset($input['vwsmp_admin_check_tumblr'])) $input['vwsmp_admin_check_tumblr'] = null;
        $input['vwsmp_admin_check_tumblr'] = ($input['vwsmp_admin_check_tumblr'] == 1 ? 1 : 0);

    // Wordpress
    if (!isset($input['vwsmp_wordpress'])){
        $input['vwsmp_wordpress']     = null;
    }
    else{
        $input['vwsmp_wordpress']     = esc_attr($input['vwsmp_wordpress']);
    }

    if (!isset($input['vwsmp_admin_check_wordpress'])) $input['vwsmp_admin_check_wordpress'] = null;
        $input['vwsmp_admin_check_wordpress'] = ($input['vwsmp_admin_check_wordpress'] == 1 ? 1 : 0);

    // RSS
    if (!isset($input['vwsmp_rss'])){
        $input['vwsmp_rss']     = null;
    }
    else{
        $input['vwsmp_rss']     = esc_attr($input['vwsmp_rss']);
    }

    if (!isset($input['vwsmp_admin_check_rss'])) $input['vwsmp_admin_check_rss'] = null;
        $input['vwsmp_admin_check_rss'] = ($input['vwsmp_admin_check_rss'] == 1 ? 1 : 0);

    // VK
    if (!isset($input['vwsmp_vk'])){
        $input['vwsmp_vk']     = null;
    }
    else{
        $input['vwsmp_vk']     = esc_attr($input['vwsmp_vk']);
    }

    if (!isset($input['vwsmp_admin_check_vk'])) $input['vwsmp_admin_check_vk'] = null;
        $input['vwsmp_admin_check_vk'] = ($input['vwsmp_admin_check_vk'] == 1 ? 1 : 0);

    // Custom Icon 1  URL
    if (!isset($input['vwsmp_custom_1'])){
        $input['vwsmp_custom_1']     = null;
    }
    else{
        $input['vwsmp_custom_1']     = esc_attr($input['vwsmp_custom_1']);
    }

    // Custom Icon Class
    if (!isset($input['vwsmp_custom_1_icon'])){
        $input['vwsmp_custom_1_icon']     = null;
    }
    else{
        $input['vwsmp_custom_1_icon']     = esc_attr($input['vwsmp_custom_1_icon']);
    }

    if (!isset($input['vwsmp_admin_check_custom_1'])) $input['vwsmp_admin_check_custom_1'] = null;
        $input['vwsmp_admin_check_custom_1'] = ($input['vwsmp_admin_check_custom_1'] == 1 ? 1 : 0);

    // Custom Icon 1  URL
    if (!isset($input['vwsmp_custom_2'])){
        $input['vwsmp_custom_2']     = null;
    }
    else{
        $input['vwsmp_custom_2']     = esc_attr($input['vwsmp_custom_2']);
    }

    // Custom Icon Class
    if (!isset($input['vwsmp_custom_2_icon'])){
        $input['vwsmp_custom_2_icon']     = null;
    }
    else{
        $input['vwsmp_custom_2_icon']     = esc_attr($input['vwsmp_custom_2_icon']);
    }

    if (!isset($input['vwsmp_admin_check_custom_2'])) $input['vwsmp_admin_check_custom_2'] = null;
        $input['vwsmp_admin_check_custom_2'] = ($input['vwsmp_admin_check_custom_2'] == 1 ? 1 : 0);

    // Custom Icon 1  URL
    if (!isset($input['vwsmp_custom_3'])){
        $input['vwsmp_custom_3']     = null;
    }
    else{
        $input['vwsmp_custom_3']     = esc_attr($input['vwsmp_custom_3']);
    }

    // Custom Icon Class
    if (!isset($input['vwsmp_custom_3_icon'])){
        $input['vwsmp_custom_3_icon']     = null;
    }
    else{
        $input['vwsmp_custom_3_icon']     = esc_attr($input['vwsmp_custom_3_icon']);
    }

     if (!isset($input['vwsmp_admin_check_custom_3'])) $input['vwsmp_admin_check_custom_3'] = null;
        $input['vwsmp_admin_check_custom_3'] = ($input['vwsmp_admin_check_custom_3'] == 1 ? 1 : 0);

    // Custom Icon 1  URL
    if (!isset($input['vwsmp_custom_4'])){
        $input['vwsmp_custom_4']     = null;
    }
    else{
        $input['vwsmp_custom_4']     = esc_attr($input['vwsmp_custom_4']);
    }

    // Custom Icon Class
    if (!isset($input['vwsmp_custom_4_icon'])){
        $input['vwsmp_custom_4_icon']     = null;
    }
    else{
        $input['vwsmp_custom_4_icon']     = esc_attr($input['vwsmp_custom_4_icon']);
    }

    if (!isset($input['vwsmp_admin_check_custom_4'])) $input['vwsmp_admin_check_custom_4'] = null;
        $input['vwsmp_admin_check_custom_4'] = ($input['vwsmp_admin_check_custom_4'] == 1 ? 1 : 0);

    // Custom Icon 1  URL
    if (!isset($input['vwsmp_custom_5'])){
        $input['vwsmp_custom_5']     = null;
    }
    else{
        $input['vwsmp_custom_5']     = esc_attr($input['vwsmp_custom_5']);
    }

    // Custom Icon Class
    if (!isset($input['vwsmp_custom_5_icon'])){
        $input['vwsmp_custom_5_icon']     = null;
    }
    else{
        $input['vwsmp_custom_5_icon']     = esc_attr($input['vwsmp_custom_5_icon']);
    }

    if (!isset($input['vwsmp_admin_check_custom_5'])) $input['vwsmp_admin_check_custom_5'] = null;
        $input['vwsmp_admin_check_custom_5'] = ($input['vwsmp_admin_check_custom_5'] == 1 ? 1 : 0);


    // Position
    if (!isset($input['vwsmp_admin_radio'])){
        $input['vwsmp_admin_radio']     = null;
    }
    else{
        $input['vwsmp_admin_radio']     = esc_attr($input['vwsmp_admin_radio']);
    }

    // Style
    if (!isset($input['vwsmp_admin_radio_style'])){
        $input['vwsmp_admin_radio_style']     = null;
    }
    else{
        $input['vwsmp_admin_radio_style']     = esc_attr($input['vwsmp_admin_radio_style']);
    }

    // Color
    if (!isset($input['vwsmp_color'])){
        $input['vwsmp_color']     = null;
    }
    else{
        $input['vwsmp_color']     = esc_attr($input['vwsmp_color']);
    }

    // Hover Color
    if (!isset($input['vwsmp_hover_color'])){
        $input['vwsmp_hover_color']     = null;
    }
    else{
        $input['vwsmp_hover_color']     = esc_attr($input['vwsmp_hover_color']);
    }

    // Background Color
    if (!isset($input['vwsmp_background_color'])){
        $input['vwsmp_background_color']     = null;
    }
    else{
        $input['vwsmp_background_color']     = esc_attr($input['vwsmp_background_color']);
    }

    // Background Hover Color
    if (!isset($input['vwsmp_background_hover_color'])){
        $input['vwsmp_background_hover_color']     = null;
    }
    else{
        $input['vwsmp_background_hover_color']     = esc_attr($input['vwsmp_background_hover_color']);
    }

    // Font Size
    if (!isset($input['vwsmp_font_size'])){
        $input['vwsmp_font_size']     = 18;
    }
    else{
        $input['vwsmp_font_size']     = esc_attr($input['vwsmp_font_size']);
    }

    // Border Radius
    if (!isset($input['vwsmp_border_radius'])){
        $input['vwsmp_border_radius']     = null;
    }
    else{
        $input['vwsmp_border_radius']     = esc_attr($input['vwsmp_border_radius']);
    }

    // Border Radius
    if (!isset($input['vwsmp_margin_top'])){
        $input['vwsmp_margin_top']     = 0;
    }
    else{
        $input['vwsmp_margin_top']     = esc_attr($input['vwsmp_margin_top']);
    }

    // Border Radius
    if (!isset($input['vwsmp_margin_right'])){
        $input['vwsmp_margin_right']     = 0;
    }
    else{
        $input['vwsmp_margin_right']     = esc_attr($input['vwsmp_margin_right']);
    }

    // Border Radius
    if (!isset($input['vwsmp_margin_bottom'])){
        $input['vwsmp_margin_bottom']     = 0;
    }
    else{
        $input['vwsmp_margin_bottom']     = esc_attr($input['vwsmp_margin_bottom']);
    }

    // Border Radius
    if (!isset($input['vwsmp_margin_left'])){
        $input['vwsmp_margin_left']     = 0;
    }
    else{
        $input['vwsmp_margin_left']     = esc_attr($input['vwsmp_margin_left']);
    }

 return $input;
}
